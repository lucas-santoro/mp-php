<?php
require_once '../db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.html");
    exit();
}

$paymentId = $_GET['payment_id'] ?? null;

$stmt = $pdo->prepare("SELECT * FROM transactions WHERE payment_id = :payment_id AND user_id = :user_id");
$stmt->execute([
    ':payment_id' => $paymentId,
    ':user_id' => $_SESSION['user_id']
]);

$transaction = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$transaction) {
    die("Erro: Nenhuma transação encontrada para esse pagamento.");
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamento Pendente</title>
    <link rel="stylesheet" href="../../styles/index.css">
</head>
<body>
    <div class="container">
        <h2>Pagamento Pendente</h2>
        <p>Seu pagamento ainda está sendo processado pelo Mercado Pago.</p>
        <p>Isso pode levar alguns minutos. Você pode verificar novamente mais tarde.</p>
        <p><a href="../../frontend/index.php"><button>Voltar para a página inicial</button></a></p>
    </div>
</body>
</html>
